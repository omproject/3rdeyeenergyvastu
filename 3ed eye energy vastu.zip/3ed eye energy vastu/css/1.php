<?php
// Check if the form is submitted using POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $firstName = $_POST['firstName'];
    $email = $_POST['email'];
    $phonenumber = $_POST['phonenumber'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $text = $_POST['text'];

    // Validate the form inputs if needed
    if (!empty($firstName) && !empty($email) && !empty($phonenumber) && !empty($gender) && !empty($address) && !empty($text)) {
        // Database connection
        $conn = new mysqli('localhost', 'root', '', 'astrology');

        // Check for connection error
        if ($conn->connect_error) {
            die("Connection Failed: " . $conn->connect_error);
        }

        // Prepare the SQL statement
        $stmt = $conn->prepare("INSERT INTO table1 (firstName, email, phonenumber, gender, address, text) VALUES (?, ?, ?, ?, ?, ?)");

        // Bind parameters (all strings 's')
        $stmt->bind_param("ssssss", $firstName, $email, $phonenumber, $gender, $address, $text);

        // Execute the statement and check if it was successful
        if ($stmt->execute()) {
            echo "Registration successful!";

            // Send email notification
            $to = $email; // Recipient's email
            $subject = "Registration Confirmation";
            $message = "
                Dear $firstName,\n\n
                Thank you for registering! Here are your details:\n
                Name: $firstName\n
                Email: $email\n
                Phone: $phonenumber\n
                Gender: $gender\n
                Address: $address\n
                Message: $text\n\n
                Best regards,\n
                Astrology Team
            ";
            $headers = "From: noreply@astrology.com";

            if (mail($to, $subject, $message, $headers)) {
                echo " A confirmation email has been sent to your email address.";
            } else {
                echo " Failed to send the confirmation email.";
            }
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement and connection
        $stmt->close();
        $conn->close();
    } else {
        echo "Please fill in all the fields.";
    }
}
?>
